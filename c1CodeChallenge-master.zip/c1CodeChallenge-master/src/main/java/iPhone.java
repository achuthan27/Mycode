
public class iPhone
{
	public static String decafStr=null;
	public static String shotsStr=null;
	public static String milkStr=null;
	public static String drinkStr=null;
	//public static String DecafStr=null;
    public iPhone( ) { }

    /*
     * Set the Valid option for Decaf(NO, YES and 1/2)
     * Set the option has Invalid  
     */
    public void setDecaf(String s)
    {
    	switch (s.toUpperCase()) {
            case "NO":decafStr = " Decaf[NO]";
                     break;
            case "YES":decafStr = " Decaf[YES]";
                     break;
            case "1/2":decafStr = " Decaf[1/2]";
                     break;
            default: 
            	decafStr = " Decaf[INVALID]";
                break;
        }        
    }
    
    /*
     * Set the Valid option for Shots(1,2,3 and D)
     * Set the option has Invalid  
     */
    public void setShots(String s)
    {
    	switch (s.toUpperCase()) {
	        case "1":shotsStr = " Shots[1]";
	                 break;
	        case "2":shotsStr = " Shots[2]";
	                 break;
	        case "3":shotsStr = " Shots[3]";
	                 break;
	        case "D":shotsStr = " Shots[D]";
	        		break;
	        default: shotsStr = " Shots[INVALID]";
	        		break;
    	}
    }

    /*
     * Set the Valid option for Milk(1,2,WH and NF)
     * Set the option has Invalid  
     */    
    public void setMilk(String s)
    {
    	switch (s.toUpperCase()) {
	        case "1":milkStr = " Milk[1]";
	                 break;
	        case "2":milkStr = " Milk[2]";
	                 break;
	        case "WH":milkStr = " Milk[WH]";
	                 break;
	        case "NF":milkStr = " Milk[NF]";
	        		break;
	        default:  milkStr = " MILK[INVALID]";
            		break;
    	}
    }
    
    /*
     * Set the Valid option for Drink(A,L,C,CM,CDL,E and ECP)
     * Set the option has Invalid  
     */   
    public void setDrink(String s)
    {
    	switch (s.toUpperCase()) {
	        case "A":drinkStr = " Drink[A]";
	                 break;
	        case "L":drinkStr = " Drink[L]";
	        		break;
	        case "M":drinkStr = " Drink[M]";
	        		break;
	        case "C":drinkStr = " Drink[C]";
	        		break;
	        case "CM":drinkStr = " Drink[CM]";
	        		break;
	        case "CDL":drinkStr = " Drink[CDL]";
	        		break;
	        case "E":drinkStr = " Drink[E]";
	        		break;
	        case "ECP":drinkStr = " Drink[ECP]";
	        		break;
	        default:drinkStr = "Drink[INVALID]";
	        		break;
    	}
    }
    
    public String sendCommand()
    {
    	String ret = "Robot:";
    	ret = ret + decafStr + shotsStr +  milkStr +drinkStr;
    	resetOptions();
    	// return command string for robot
        return ret ; 
    }
    
    /*
     * Reset the Espresso options at the end of Test
     *   
     */ 
    public void resetOptions()
    {
    	decafStr="";
    	shotsStr="";
    	milkStr="";
    	drinkStr="";
    }
    
}
